#!/bin/bash
# Get timestamp
timestamp=$(date +"%Y%m%d_%H%M%S")
export HASHHTML=""
export HASHNONHTML="--"
export SQLLINESIZE=400
export LONG_RUN_QUR_HOURS=1

# Function to gather CPU, memory, and file system utilization from each node
get_utilization() {

echo "<p> <table border='0' bordercolor='#E67E22' width='20%' align='left'> <tr> <th scope="col"> DB HC Report Generated at $timestamp </td> </tr> </table> <p><br></p>"

   #  echo '<style type="text/css"> table { background:white ;font-size: 80%; } th { font:bold 11pt Arial,Helvetica,sans-serif; align: left; color: #FFFFFF; background: #AF601A; } td { font:10pt; background: #FFFFFF; padding: 3px; } </style>'
 
   echo "<p> <table border='0' bordercolor='#E67E22' width='20%' align='left'> <tr> <th scope="col"> CPU, Memory Utilization </td> </tr> </table> <p>"
   for node in fus-ora-ofk1-d-fjumg1 fus-ora-ofk1-d-fjumg2 fus-ora-ofk1-d-fjumg3 fus-ora-ofk1-d-fjumg4;
   do
      ssh $node "
      # Commands to gather CPU
      # echo '<p><br></p>'
      echo '<p><br><br><table width='20%' border='1'><tr><th>Node: $node</th></tr></table>'
      echo '<table border='0' bordercolor='#E67E22' align='left' summary='Script output'> <tr> <th>CPU</th> <th>Utilization</th> </tr>'
      top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\([0-9.]*\)%* id.*/\1/' | awk '{print \"<tr><td>CPU</td><td>\" 100 - \$1 \"%</td></tr>\"}'
      # echo '</table></p>'

       # Commands to gather memory
       echo '<tr><th>Memory</th><th>Total</th><th>Used</th><th>Free</th><th>Shared</th><th>Cache/Buffer</th><th>Available</th></tr>'
       free -m | awk 'NR==2 {print \"<tr><td>\" \$1 \"</td><td>\" \$2 \"</td><td>\" \$3 \"</td><td>\" \$4 \"</td><td>\" \$5 \"</td><td>\" \$6 \"</td><td>\" \$7 \"</td></tr>\"}'
       echo '</table></p><p><br><br></p>'

       "
    done
}
# Call function to get CPU, memory, and file system utilization from each node
get_utilization >> /tmp/DBHC_${ORACLE_UNQNAME}_${timestamp}.html

# Set Oracle environment variables if ORACLE_HOME is not set
if [ -z "$ORACLE_HOME" ]; then
    echo "ORACLE_HOME is not set. Please set it to your Oracle software directory."
    exit 1
fi

export PATH=$ORACLE_HOME/bin:$PATH

# #####################
# Getting DB Block Size:
# #####################
VAL302=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off;
prompt
select value from v\$parameter where name='db_block_size';
exit;
EOF
)
blksize=`echo ${VAL302}|perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'|cut -f1 -d '.'`

# Get PDB names
pdbs=$(sqlplus -S "/ as sysdba" <<EOF1
set pages 0 feedback off;
prompt
select name from v\$containers where con_id > 2;
exit;
EOF1
)


sqlplus -S "/ as sysdba" << EOF_CDB
set feedback off
set linesize ${SQLLINESIZE} pages 1000
-- Enable HTML color format:
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { background: #E67E22; font-size: 80%; } th { font:bold 10pt Arial,Helvetica,sans-serif; align: left; color: #FFFFFF; background: #AF601A; } td { font:10pt; background: #FFFFFF; padding: 3px; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF

--${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF

spool ${cur_dir}/Reports/HC_RPT/DBHC_${ORACLE_UNQNAME}_${timestamp}.html append 

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT DATABASE STATUS
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT DATABASE STATUS
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^

col HOST_NAME for a35
select INSTANCE_NAME,HOST_NAME,to_char(STARTUP_TIME,'YYYY-MM-DD HH24:MI:SS') STARTUP_TIME,open_mode, LOGINS,LOG_MODE,STATUS,DATABASE_ROLE,controlfile_type from gv\$instance,v\$database ORDER BY 1;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT PLUGGABLE DB STATUS 
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT PDB Status
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^
col name for a15
col open_time for a33
select inst_id,con_id,name,dbid,open_mode,open_time from gv\$containers order by 3,1;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT DB REGISTRY STATUS
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT DB Registry 
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^

col STATUS for a15
col COMP_NAME for a40
select COMP_ID,COMP_NAME,VERSION,STATUS,MODIFIED from dba_registry;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT DB BACKUP STATUS LAST 7 DAYS
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT DB BACKUP
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^

col DATBASE_NAME for a12
col BACKUP_TYPE for a28
col STARTED_TIME for a20
col END_TIME for a20
col TIME_TAKEN_DISPLAY for a20
col STATUS for a20
col JOB_ID for a40
SELECT (SELECT name FROM v\$database) "DATBASE_NAME",  
decode(to_char(rj.start_time, 'd'), 1, 'DATABASE FULL BACKUP','DATABASE DAILY INCR BACKUP')  "BACKUP_TYPE",
max(rj.START_TIME) STARTED_TIME,
rj.END_TIME,
rj.TIME_TAKEN_DISPLAY,
rj.STATUS,
rj.COMMAND_ID "JOB_ID"
from v\$rman_backup_job_details rj, v\$rman_status rs
where rj.COMMAND_ID=rs.COMMAND_ID and rj.INPUT_TYPE='DB INCR'
group by rs.sid,rj.COMMAND_ID,rj.STATUS,rj.START_TIME,rj.END_TIME,rj.INPUT_TYPE,rj.TIME_TAKEN_DISPLAY
having max(rj.START_TIME) > sysdate-7 order by rj.START_TIME desc;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT ASM STATISTICS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT ASM STATISTICS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^

select name,state,OFFLINE_DISKS,total_mb,free_mb,
${HASHHTML} case when ROUND((1-(free_mb / total_mb))*100, 2) > 90 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(ROUND((1-(free_mb / total_mb))*100, 2),999.99) || '</span>' else to_char(ROUND((1-(free_mb / total_mb))*100, 2),999.99) end as "%FULL"
${HASHNONHTML} to_char(ROUND((1-(free_mb / total_mb))*100, 2),999.99) "%FULL"
from v\$asm_diskgroup;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT FRA STATISTICS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT FRA STATISTICS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT FRA SIZE
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT ^^^^^^^^^
${HASHNONHTML} PROMPT FRA_SIZE:
${HASHNONHTML} PROMPT ^^^^^^^^^

col name for a35
SELECT NAME,NUMBER_OF_FILES,SPACE_LIMIT/1024/1024/1024 AS TOTAL_SIZE_GB,SPACE_USED/1024/1024/1024 SPACE_USED_GB,
SPACE_RECLAIMABLE/1024/1024/1024 SPACE_RECLAIMABLE_GB,ROUND((SPACE_USED-SPACE_RECLAIMABLE)/SPACE_LIMIT * 100, 1) AS "%FULL_AFTER_CLAIM",
${HASHHTML} case when ROUND((SPACE_USED)/SPACE_LIMIT * 100, 1) > 90 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(ROUND((SPACE_USED)/SPACE_LIMIT * 100, 1),999.99) || '</span>' else to_char(ROUND((SPACE_USED)/SPACE_LIMIT * 100, 1),999.99) end as "%FULL_NOW"
${HASHNONHTML} to_char(ROUND((SPACE_USED)/SPACE_LIMIT * 100, 1),999.99) "%FULL_NOW"
FROM V\$RECOVERY_FILE_DEST;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT FRA COMPONENTS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT FRA_COMPONENTS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^

select * from v\$flash_recovery_area_usage;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT FLASHBACK RESTORE POINTS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT FLASHBACK RESTORE POINTS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^

col SCN                for 999999999999999999
col time               for a35 
col RESTORE_POINT_TIME for a35
col name               for a40
select NAME,SCN,TIME,STORAGE_SIZE/1024/1024/1024 STORAGE_SIZE_GB from v\$restore_point;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT REDO LOG SWITCHES
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT REDO LOG SWITCHES:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^

set linesize ${SQLLINESIZE}
select thread# as INST, trunc(completion_time) as "date", 
to_char(completion_time,'Dy') as "Day",
sum(decode(to_char(completion_time,'HH24'),'00',1,0)) as "00",
sum(decode(to_char(completion_time,'HH24'),'01',1,0)) as "01",
sum(decode(to_char(completion_time,'HH24'),'02',1,0)) as "02",
sum(decode(to_char(completion_time,'HH24'),'03',1,0)) as "03",
sum(decode(to_char(completion_time,'HH24'),'04',1,0)) as "04",
sum(decode(to_char(completion_time,'HH24'),'05',1,0)) as "05",
sum(decode(to_char(completion_time,'HH24'),'06',1,0)) as "06",
sum(decode(to_char(completion_time,'HH24'),'07',1,0)) as "07",
sum(decode(to_char(completion_time,'HH24'),'08',1,0)) as "08",
sum(decode(to_char(completion_time,'HH24'),'09',1,0)) as "09",
sum(decode(to_char(completion_time,'HH24'),'10',1,0)) as "10",
sum(decode(to_char(completion_time,'HH24'),'11',1,0)) as "11",
sum(decode(to_char(completion_time,'HH24'),'12',1,0)) as "12",
sum(decode(to_char(completion_time,'HH24'),'13',1,0)) as "13",
sum(decode(to_char(completion_time,'HH24'),'14',1,0)) as "14",
sum(decode(to_char(completion_time,'HH24'),'15',1,0)) as "15",
sum(decode(to_char(completion_time,'HH24'),'16',1,0)) as "16",
sum(decode(to_char(completion_time,'HH24'),'17',1,0)) as "17",
sum(decode(to_char(completion_time,'HH24'),'18',1,0)) as "18",
sum(decode(to_char(completion_time,'HH24'),'19',1,0)) as "19",
sum(decode(to_char(completion_time,'HH24'),'20',1,0)) as "20",
sum(decode(to_char(completion_time,'HH24'),'21',1,0)) as "21",
sum(decode(to_char(completion_time,'HH24'),'22',1,0)) as "22",
sum(decode(to_char(completion_time,'HH24'),'23',1,0)) as "23",
 count(1) as "total"
from
v\$archived_log
where first_time > trunc(sysdate-7)
and dest_id = (select dest_id from V\$ARCHIVE_DEST_STATUS where status='VALID' and type='LOCAL')
group by thread#, trunc(completion_time), to_char(completion_time, 'Dy') order by 2 desc ,1;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT STANDBY SYNC
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Standby  Sync 
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^

set linesize ${SQLLINESIZE}
   SELECT  DISTINCT GVD.INST_ID,
(SELECT UPPER(SUBSTR(HOST_NAME,1,(DECODE(INSTR(HOST_NAME,'.'),0,LENGTH(HOST_NAME), (INSTR(HOST_NAME,'.')-1))))) FROM GV\$INSTANCE WHERE INST_ID=GVI.INST_ID) HOSTNAME,
GVD.NAME "DATABASE",
(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE ARCHIVED='YES' AND DEST_ID=2 AND THREAD# = GVI.THREAD#) LOG_ARCHIVED,
(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES' AND THREAD# = GVI.THREAD#) LOG_APPLIED,
(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE ARCHIVED='YES' AND DEST_ID=2 AND THREAD# = GVI.THREAD#)-(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES' AND THREAD# = GVI.THREAD#) LOG_GAP,
(SELECT TO_CHAR(MAX(COMPLETION_TIME),'DD-MON/HH24:MI') FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES') APPLIED_TIME
FROM GV\$DATABASE GVD, GV\$INSTANCE GVI, V\$ARCHIVED_LOG GVA
WHERE GVI.THREAD#=GVA.THREAD#
AND GVI.INST_ID=GVD.INST_ID
ORDER BY GVD.INST_ID;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT ALERT LOG ERRORS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT ALERT LOG 
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^

set lines 500
set pages 50
col originating_timestamp for a40
col rownum for 999999
col Error for a150
ALTER SESSION SET NLS_LANGUAGE = 'AMERICAN';
select inst_id, -- rownum "Line",
TO_CHAR(originating_timestamp,'DD-MON-YYYY HH24:MI:SS') AS time, message_text "Error"
from TABLE(gv\$(cursor(select inst_id, originating_timestamp, message_text
from v\$diag_alert_ext
where originating_timestamp >= (sysdate - 1) AND message_type not IN (1) 
AND regexp_like(message_text, '(ORA-|error)'))))
order by originating_timestamp asc;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='35%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT MODIFIED PARAMETERS SINCE STARTUP
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} PROMPT MODIFIED PARAMETERS SINCE INSTANCE STARTUP:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

col INS for 999
col name for a45
col VALUE for a80
col DEPRECATED for a10
select INST_ID INS,NAME,VALUE,ISDEFAULT "DEFAULT",ISDEPRECATED "DEPRECATED" from gv\$parameter where ISMODIFIED = 'SYSTEM_MOD' order by 1;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT RESOURCE LIMIT
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT RESOURCE LIMIT:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^

col INITIAL_ALLOCATION  for a20
col LIMIT_VALUE         for a20
col RESOURCE_NAME       for a40
select * from gv\$resource_limit order by RESOURCE_NAME,1;

spool off;
EOF_CDB

# Iterate over each PDB
for pdb in $pdbs; 
do
   sqlplus -S "/ as sysdba" <<EOF_PDB
   set feedback off;
   set linesize ${SQLLINESIZE} pages 1000
   spool ${cur_dir}/Reports/HC_RPT/DBHC_${ORACLE_UNQNAME}_${timestamp}.html append
   alter session set container=$pdb;

${HASHHTML}  PROMPT
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHHTML} PROMPT CONNECTED TO PDB - $pdb 
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF 


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT DB REGISTRY STATUS 
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT PDB Registry
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^

col STATUS for a15
col COMP_NAME for a40
select COMP_ID,COMP_NAME,VERSION,STATUS,MODIFIED from dba_registry;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT NO OF ACTIVE - INACTIVE SESSIONS 
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT ACTIVE-INACTIVE SESSIONS 
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

set pages 350
col username for a40
col status for a15
comp sum of session_count on report
bre on report
SELECT s.username,COUNT(*) AS session_count, s.status
FROM gV\$SESSION S,gV\$PROCESS P
WHERE S.PADDR=P.ADDR
AND S.USERNAME IS NOT NULL
group by s.username,s.status
ORDER BY 3,2 desc;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT ACTIVE SESSION - BY Wait Events
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT Active Session - by Wait Events
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

col event for a50
select inst_id,event,count(*) from gv\$session where username is not null and status='ACTIVE'
and event not in('SQL*Net message from client','SQL*Net message to client','smon timer','pmon timer','Streams AQ: waiting for messages in the queue')
group by inst_id,event order by 1,3;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML}  PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT ACTIVE SESSIONS
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML}  PROMPT
${HASHNONHTML}  PROMPT Active SESSIONS
${HASHNONHTML}  PROMPT ^^^^^^^^^^^^^^^

col inst_id for 99
col username for a16
col osuser for a14
col event for a20 trunc
col inst for 99999
col SESS for a15
col module for a35
select inst_id, s.sid||','||s.serial# as SESS , rpad(s.username,14,' ') as "DB User",osuser, s.sql_id,s.sql_child_number Parallel,
rpad(upper(substr(s.MODULE,instr(s.MODULE,'\',-1)+1)),29,' ') as "MODULE", s.event,
round(LAST_CALL_ET/60) ACTIVE_Mins
from gv\$session s
where s.status='ACTIVE' and username is not null
and s.username not like 'SYS%' and s.username not like 'DBSNMP'
and s.event not in('SQL*Net message from client','SQL*Net message to client','smon timer','pmon timer','Streams AQ: waiting for messages in the queue')
and rownum <=25
order by LAST_CALL_ET desc ;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT  LONG RUNNING QUERRIES MORE THAN [${LONG_RUN_QUR_HOURS}] Hours
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} PROMPT Queries Running For More Than [${LONG_RUN_QUR_HOURS}] Hour:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col module for a30
col DURATION_HOURS for 99999.9
col STARTED_AT for a13
col "USERNAME| SID,SERIAL#" for a30
col "SQL_ID | SQL_TEXT" for a120
SELECT 
    username || '| ' || sid || ',' || serial# AS "USERNAME| SID,SERIAL#", 
    SUBSTR(MODULE, 1, 30) AS "MODULE", 
    TO_CHAR(SYSDATE - last_call_et / 24 / 60 / 60, 'DD-MON HH24:MI') AS STARTED_AT,
    last_call_et / 60 / 60 AS "DURATION_HOURS",
    SQL_ID || ' | ' || 
    SUBSTR((SELECT LISTAGG(SUBSTR(SQL_FULLTEXT, 1, 80), '; ') WITHIN GROUP (ORDER BY SQL_FULLTEXT) FROM gv\$sql WHERE address = sql_address), 1, 80) AS "SQL_ID | SQL_TEXT"
FROM  gv\$session 
WHERE 
    username IS NOT NULL 
    AND module IS NOT NULL 
    AND last_call_et > 60 * 60 * ${LONG_RUN_QUR_HOURS}
    AND status = 'ACTIVE';

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT CURRENT BLOCKING SESSIONS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT BLOCKED SESSIONS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^

col module for a27
col event for a24
col MACHINE for a27
col "WA_ST|WAITD|ACT_SINC|LOG_T" for a38
col "INST|USER|SID,SERIAL#" for a30
col "INS|USER|SID,SER|MACHIN|MODUL" for a70
col "PREV|CURR SQLID" for a27
col "I|BLKD_BY" for a12 
select /*+RULE*/
substr(s.INST_ID||'|'||s.USERNAME||'| '||s.sid||','||s.serial#||' |'||substr(s.MACHINE,1,22)||'|'||substr(s.MODULE,1,18),1,65)"INS|USER|SID,SER|MACHIN|MODUL"
,substr(w.state||'|'||round(w.WAIT_TIME_MICRO/1000000)||'|'||LAST_CALL_ET||'|'||to_char(LOGON_TIME,'ddMon'),1,38) "WA_ST|WAITD|ACT_SINC|LOG_T"
,substr(w.event,1,24) "EVENT"
,s.FINAL_BLOCKING_INSTANCE||'|'||s.FINAL_BLOCKING_SESSION "I|BLKD_BY"
from    gv\$session s, gv\$session_wait w
where   s.USERNAME is not null
and     s.FINAL_BLOCKING_SESSION is not null
and     s.sid=w.sid
and     s.STATUS='ACTIVE'
order by "I|BLKD_BY" desc,w.event,"INS|USER|SID,SER|MACHIN|MODUL","WA_ST|WAITD|ACT_SINC|LOG_T" desc;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT TABLESPACE SIZE
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT TABELSPACE SIZE:  [Based on Datafiles MAXSIZE]
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^

set pages 1000 linesize ${SQLLINESIZE} tab off
col tablespace_name for A25
col Total_MB for 999999999999
col Used_MB for 999999999999
col '%Used' for 999.99
comp sum of Total_MB on report
comp sum of Used_MB   on report
bre on report
select tablespace_name,
       (tablespace_size*$blksize)/(1024*1024) Total_MB,
       (used_space*$blksize)/(1024*1024) Used_MB,
      -- used_percent "%Used"
${HASHHTML} case when used_percent > 90 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(used_percent,999.99) || '</span>' else to_char(used_percent,999.99) end as "%Used"
${HASHNONHTML} to_char(used_percent,999.99) "%Used"
from dba_tablespace_usage_metrics ORDER BY 4 DESC;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT CURRENT RUNNING JOBS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT 
${HASHNONHTML} PROMPT Current Running Jobs:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^

${HASHHTML}col INS				for 999
${HASHHTML}col "JOB_NAME|OWNER|SPID|SID"	for a70
${HASHHTML}col ELAPSED_TIME		for a17
${HASHHTML}col CPU_USED 			for a17
${HASHHTML}col "WAIT_SEC"  		for 9999999999
${HASHHTML}col WAIT_CLASS 			for a15
${HASHHTML}col "BLKD_BY" 			for 9999999
${HASHHTML}col "WAITED|WCLASS|EVENT" 	for a45
${HASHHTML}select j.RUNNING_INSTANCE INS,j.JOB_NAME ||' | '|| j.OWNER||' |'||SLAVE_OS_PROCESS_ID||'|'||j.SESSION_ID"JOB_NAME|OWNER|SPID|SID"
${HASHHTML},s.FINAL_BLOCKING_SESSION "BLKD_BY",ELAPSED_TIME,CPU_USED
${HASHHTML},substr(s.SECONDS_IN_WAIT||'|'||s.WAIT_CLASS||'|'||s.EVENT,1,45) "WAITED|WCLASS|EVENT",S.SQL_ID
${HASHHTML}from dba_scheduler_running_jobs j, gv\$session s
${HASHHTML}where   j.RUNNING_INSTANCE=S.INST_ID(+)
${HASHHTML}and     j.SESSION_ID=S.SID(+)
${HASHHTML}order by "JOB_NAME|OWNER|SPID|SID",ELAPSED_TIME;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT FAILED DBMS_SCHEDULER JOBS IN THE LAST 24H
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT FAILED DBMS_SCHEDULER JOBS IN THE LAST 24H:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHHTML}col LOG_DATE for a36
${HASHHTML}col OWNER for a15
${HASHHTML}col JOB_NAME for a35
${HASHHTML}col STATUS for a11
${HASHHTML}col RUN_DURATION for a20
${HASHHTML}col ID for 99
${HASHHTML}select INSTANCE_ID ID,JOB_NAME,OWNER,LOG_DATE,STATUS,ERROR#,RUN_DURATION from DBA_SCHEDULER_JOB_RUN_DETAILS where LOG_DATE > sysdate-1 and STATUS='FAILED' order by JOB_NAME,LOG_DATE;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT ACTIVE INCIDENTS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Active Incidents:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^

set linesize ${SQLLINESIZE}
col RECENT_PROBLEMS_1_WEEK_BACK for a45
select PROBLEM_KEY RECENT_PROBLEMS_1_WEEK_BACK,to_char(FIRSTINC_TIME,'DD-MON-YY HH24:mi:ss') FIRST_OCCURENCE,to_char(LASTINC_TIME,'DD-MON-YY HH24:mi:ss')
LAST_OCCURENCE FROM V\$DIAG_PROBLEM WHERE LASTINC_TIME > SYSDATE -15;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT OUTSTANDING ALERTS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT OUTSTANDING ALERTS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^

col CREATION_TIME for a40
col REASON for a80
select REASON,CREATION_TIME,METRIC_VALUE from DBA_OUTSTANDING_ALERTS;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT CORRUPTED BLOCKS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT CORRUPTED BLOCKS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^

select * from V\$DATABASE_BLOCK_CORRUPTION;


${HASHHTML} PROMPT

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <p> <table border='0' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT AUTOTASK INTERNAL MAINTENANCE WINDOWS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT AUTOTASK INTERNAL MAINTENANCE WINDOWS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHHTML}col WINDOW_NAME for a17
${HASHHTML}col NEXT_RUN for a20
${HASHHTML}col ACTIVE for a6
${HASHHTML}col OPTIMIZER_STATS for a15
${HASHHTML}col SEGMENT_ADVISOR for a15
${HASHHTML}col SQL_TUNE_ADVISOR for a16
${HASHHTML}SELECT WINDOW_NAME,TO_CHAR(WINDOW_NEXT_TIME,'DD-MM-YYYY HH24:MI:SS') NEXT_RUN,AUTOTASK_STATUS STATUS,WINDOW_ACTIVE ACTIVE,OPTIMIZER_STATS,SEGMENT_ADVISOR,SQL_TUNE_ADVISOR FROM DBA_AUTOTASK_WINDOW_CLIENTS;






${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} ${HASHMA}PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} ${HASHMA}PROMPT MEMORY ADVISORS
${HASHHTML} ${HASHMA}PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} PROMPT MEMORY UTILIZATION:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT ORACLE MEMORY UTILIZATION
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

col inst_id heading ins for 999
col COMPONENT           for a35
col CURRENT_SIZE_MB     for 99999999999
col MAX_SIZE_MB         for 99999999999
select INST_ID,COMPONENT,USER_SPECIFIED_SIZE/1024/1024 USER_SPECIFIED_SIZE_MB,CURRENT_SIZE/1024/1024 CURRENT_SIZE_MB,MAX_SIZE/1024/1024 MAX_SIZE_MB from gv\$memory_dynamic_components where COMPONENT not like '%K buffer%' and COMPONENT not in ('ASM Buffer Cache','KEEP buffer cache','RECYCLE buffer cache','unified pga pool','Data Transfer Cache') order by COMPONENT,INST_ID;


${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} PROMPT MEMORY ADVISORS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT SGA ADVISOR
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT SGA ADVISOR:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^

${HASHHTML}col ESTD_DB_TIME for 99999999999999999
${HASHHTML}col ESTD_DB_TIME_FACTOR for 9999999999999999999999999999
${HASHHTML}select * from V\$SGA_TARGET_ADVICE where SGA_SIZE_FACTOR > .6 and SGA_SIZE_FACTOR < 1.6;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML}  PROMPT Buffer Cache ADVISOR
${HASHHTML}  PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT BUFFER CACHE ADVISOR:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^

${HASHHTML}col ESTD_SIZE_MB for 9999999999999
${HASHHTML}col ESTD_PHYSICAL_READS for 99999999999999999999
${HASHHTML}col ESTD_PHYSICAL_READ_TIME for 99999999999999999999
${HASHHTML}select SIZE_FACTOR "%SIZE",SIZE_FOR_ESTIMATE ESTD_SIZE_MB,ESTD_PHYSICAL_READS,ESTD_PHYSICAL_READ_TIME,ESTD_PCT_OF_DB_TIME_FOR_READS
${HASHHTML}from V\$DB_CACHE_ADVICE where SIZE_FACTOR >.8 and SIZE_FACTOR<1.3;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} ${HASHMA}PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} ${HASHMA}PROMPT Shared Pool ADVISOR
${HASHHTML} ${HASHMA}PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000


${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT SHARED POOL ADVISOR:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^

${HASHHTML}col SIZE_MB for 99999999999
${HASHHTML}col SIZE_FACTOR for 99999999
${HASHHTML}col ESTD_SIZE_MB for 99999999999999999999
${HASHHTML}col LIB_CACHE_SAVED_TIME for 99999999999999999999999999
${HASHHTML}select SHARED_POOL_SIZE_FOR_ESTIMATE SIZE_MB,SHARED_POOL_SIZE_FACTOR "%SIZE",SHARED_POOL_SIZE_FOR_ESTIMATE/1024/1024 ESTD_SIZE_MB,ESTD_LC_TIME_SAVED LIB_CACHE_SAVED_TIME,
${HASHHTML}ESTD_LC_LOAD_TIME PARSING_TIME from V\$SHARED_POOL_ADVICE
${HASHHTML}where SHARED_POOL_SIZE_FACTOR > .9 and SHARED_POOL_SIZE_FACTOR  < 1.6;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT PGA ADVISOR
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT PGA ADVISOR:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^

${HASHHTML}col SIZE_FACTOR  for 999999999
${HASHHTML}col ESTD_SIZE_MB for 99999999999999999999
${HASHHTML}col MB_PROCESSED for 99999999999999999999
${HASHHTML}col ESTD_TIME for 99999999999999999999
${HASHHTML}select PGA_TARGET_FACTOR "%SIZE",PGA_TARGET_FOR_ESTIMATE/1024/1024 ESTD_SIZE_MB,BYTES_PROCESSED/1024/1024 MB_PROCESSED,
${HASHHTML}ESTD_TIME,ESTD_PGA_CACHE_HIT_PERCENTAGE PGA_HIT,ESTD_OVERALLOC_COUNT PGA_SHORTAGE
${HASHHTML}from V\$PGA_TARGET_ADVICE where PGA_TARGET_FACTOR > .7 and PGA_TARGET_FACTOR < 1.6;


${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT TOP FRAGMENTED TABLES:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT TOP FRAGMENTED TABLES
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
col "%RECLAIMABLE_SPACE" for 99
col owner                for a30
col "%FRAGMENTED_SPACE"  for a17
col LAST_ANALYZED for a13

select * from (select owner,table_name,to_char(LAST_ANALYZED, 'DD-MON-YYYY') LAST_ANALYZED,
round(blocks * ${blksize}/1024/1024)     "FULL_SIZE_MB",
round(num_rows * avg_row_len/1024/1024)  "ACTUAL_SIZE_MB",
round(blocks * ${blksize}/1024/1024) - round(num_rows * avg_row_len/1024/1024) "FRAGMENTED_SPACE_MB",
round(((round((blocks * ${blksize}/1024/1024)) - round((num_rows * avg_row_len/1024/1024))) / round((blocks * ${blksize}/1024/1024))) * 100)||'%' "%FRAGMENTED_SPACE"
from dba_tables
where blocks>10
-- Exclude SYS objects:
and owner <> 'SYS'
and round(blocks * ${blksize}/1024/1024) > 10
-- Fragmented Space must be > 30%:
and ((round((blocks * ${blksize}/1024/1024)) - round((num_rows * avg_row_len/1024/1024))) / round((blocks * ${blksize}/1024/1024))) * 100 > 30
order by "FRAGMENTED_SPACE_MB" desc) where rownum<11;

PROMPT Hint: The accuracy of the FRAGMENTED TABLES list depends on having a recent STATISTICS.

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT RECYCLEBIN OBJECTS#
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} PROMPT RECYCLEBIN OBJECTS#: [Purging DBA_RECYCLEBIN can boost the performance of X$ tables]
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^

col "RECYCLED_OBJECTS#" for 999999999999999999
col "TOTAL_SIZE_MB"     for 99999999999999
set feedback off
select
${HASHHTML} case when count(*) > 1000 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(count(*)) || '</span>' else to_char(count(*)) end as "RECYCLED_OBJECTS#",
${HASHNONHTML} count(*) "RECYCLED_OBJECTS#",
${HASHHTML} case when sum(space)*${blksize}/1024/1024  > 1024 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(sum(space)*${blksize}/1024/1024) || '</span>' else to_char(sum(space)*${blksize}/1024/1024) end as "TOTAL_SIZE_MB"
${HASHNONHTML} sum(space)*${blksize}/1024/1024 "TOTAL_SIZE_MB"
from dba_recyclebin group by 1;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT CURRENT OS / HARDWARE STATISTICS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000


${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} PROMPT CURRENT OS / HARDWARE STATISTICS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

select stat_name,value from v\$osstat;




${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT NEW CREATED OBJECTS [Last 24H]
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} prompt
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} prompt No of Created objects [Last 24H]
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} prompt
col owner for a30
col object_name for a30
col object_type for a19
col created for a20
select count(*),object_type,owner from dba_objects
where created > sysdate-1
and owner <> 'SYS'
group by object_type,owner
order by owner,object_type;


${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='0' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT MODIFIED OBJECTS [Last 24H]
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='0' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000

${HASHNONHTML} prompt
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} prompt Modified objects in the Last 24H ...
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

${HASHNONHTML} prompt
col owner for a30
col object_name for a30
col object_type for a19
col LAST_DDL_TIME for a20
select count(*),object_type,owner from dba_objects
where LAST_DDL_TIME > sysdate-1
and owner <> 'SYS'
group by object_type,owner
order by owner,object_type;
spool off
exit;
EOF_PDB
done 

echo -e "\t*** DB HC Report successfully created  at  ${cur_dir}/Reports/HC_RPT/DBHC_${ORACLE_UNQNAME}_${timestamp}.html "
echo -e "\n"
echo -e "\n\t*** Press q to return: \c "

read option
        if [ "$option" = "q" -o "$option" = "Q" ]
        then
            tput clear
          exit 0
        fi
