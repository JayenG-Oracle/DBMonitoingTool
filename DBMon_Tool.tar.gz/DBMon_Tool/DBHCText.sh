#!/bin/bash
# Get timestamp
timestamp=$(date +"%Y%m%d_%H%M%S")
export LONG_RUN_QUR_HOURS=1
cur_dir=$(pwd)

echo -e "\n\t*** DB Health Check Report generation is in progress... ***"

# Set Oracle environment variables if ORACLE_HOME is not set
if [ -z "$ORACLE_HOME" ]; then
    echo "ORACLE_HOME is not set. Please set it to your Oracle software directory."
    exit 1
fi

export PATH=$ORACLE_HOME/bin:$PATH

### Get DB Block Size:
VAL302=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off;
prompt
select value from v\$parameter where name='db_block_size';
exit;
EOF
)
blksize=`echo ${VAL302}|perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'|cut -f1 -d '.'`

### Get PDB names
pdbs=$(sqlplus -S "/ as sysdba" <<EOF1
set pages 0 feedback off;
prompt
select name from v\$containers where con_id > 2;
exit;
EOF1
)

### Gether cdb level details
sqlplus -S "/ as sysdba" << EOF_CDB
spool /tmp/DBHC_${ORACLE_UNQNAME}_${timestamp}.txt append
CLEAR BREAKS
CLEAR COLUMNS
set colsep |
set lines 200 pages 200
SET HEAD ON 
SET FEEDBACK OFF


PROMPT DATABASE Status
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col HOST_NAME for a30
col OPEN_MODE for a15
select INSTANCE_NAME,HOST_NAME,to_char(STARTUP_TIME,'YYYY-MM-DD HH24:MI:SS') STARTUP_TIME,open_mode, LOGINS,LOG_MODE,STATUS,DATABASE_ROLE,controlfile_type from gv\$instance,v\$database ORDER BY 1;

PROMPT 
PROMPT PLUGGABLE DB STATUS 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col name for a15
col open_time for a33
select inst_id,con_id,name,dbid,open_mode,open_time from gv\$containers order by 3,1;

PROMPT 
PROMPT DB Registry 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col STATUS for a15
col COMP_NAME for a40
select COMP_ID,COMP_NAME,VERSION,STATUS,MODIFIED from dba_registry;

PROMPT  
PROMPT DB BACKUP
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col DATBASE_NAME for a12
col BACKUP_TYPE for a28
col STARTED_TIME for a20
col END_TIME for a20
col TIME_TAKEN_DISPLAY for a20
col STATUS for a20
col JOB_ID for a40
SELECT (SELECT name FROM v\$database) "DATBASE_NAME",  
decode(to_char(rj.start_time, 'd'), 1, 'DATABASE FULL BACKUP','DATABASE DAILY INCR BACKUP')  "BACKUP_TYPE",
max(rj.START_TIME) STARTED_TIME,
rj.END_TIME,
rj.TIME_TAKEN_DISPLAY,
rj.STATUS,
rj.COMMAND_ID "JOB_ID"
from v\$rman_backup_job_details rj, v\$rman_status rs
where rj.COMMAND_ID=rs.COMMAND_ID and rj.INPUT_TYPE='DB INCR'
group by rs.sid,rj.COMMAND_ID,rj.STATUS,rj.START_TIME,rj.END_TIME,rj.INPUT_TYPE,rj.TIME_TAKEN_DISPLAY
having max(rj.START_TIME) > sysdate-7 order by rj.START_TIME desc;

PROMPT  
PROMPT ASM STATISTICS
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
COLUMN group_name             FORMAT a20                HEAD 'Disk Group'
COLUMN state                  FORMAT a11                HEAD 'State'
COLUMN type                   FORMAT a6                 HEAD 'Type'
COLUMN total_tb               FORMAT 999,999,999,999    HEAD 'Total Size (TB)'
COLUMN used_tb                FORMAT 999,999,999        HEAD 'Used Size (TB)'
COLUMN free_tb                FORMAT 999,999,999        HEAD 'Free Size (TB)'
COLUMN pct_used               FORMAT 999,99             HEAD 'Pct. Used'
compute sum label "Grand Total: " of total_tb used_tb free_tb on report
SELECT
    name   group_name
  , state  state
  , type   type
  , OFFLINE_DISKS
  , total_mb/1024/1024   total_tb
  , (total_mb - free_mb)/1024/1024  used_tb
  , free_mb/1024/1024  free_tb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM     v\$asm_diskgroup
ORDER BY     name;

PROMPT  
PROMPT FRA STATISTICS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PROMPT
PROMPT FRA_SIZE:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
COL NAME For a10
COL "%FULL_NOW" for a12
SELECT
     name,
     number_of_files,
     round(space_limit / 1024 / 1024 / 1024,2)  total_size_gb,
     round(space_used / 1024 / 1024 / 1024,2)  space_used_gb,
     round(space_reclaimable / 1024 / 1024 / 1024,2) space_reclaimable_gb,
     round((space_used - space_reclaimable) / space_limit * 100, 1) AS "%FULL_AFTER_CLAIM",
  to_char(round((space_used) / space_limit * 100, 1),        999.99) "%FULL_NOW"
FROM V\$RECOVERY_FILE_DEST;

PROMPT 
PROMPT FRA_COMPONENTS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
select * from v\$flash_recovery_area_usage;

PROMPT 
PROMPT FLASHBACK RESTORE POINTS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

col SCN                for 999999999999999999
col time               for a35 
col RESTORE_POINT_TIME for a35
col name               for a40
select CON_ID ,NAME,SCN,TIME,STORAGE_SIZE/1024/1024/1024 STORAGE_SIZE_GB,GUARANTEE_FLASHBACK_DATABASE from v\$restore_point;

PROMPT
PROMPT REDO LOG SWITCHES:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col day format a3
col total format 9999
col 00 format 999
col 01 format 999
col 02 format 999
col 03 format 999
col 04 format 999
col 04 format 999
col 05 format 999
col 06 format 999
col 07 format 999
col 08 format 999
col 09 format 999
col 10 format 999
col 11 format 999
col 12 format 999
col 13 format 999
col 14 format 999
col 15 format 999
col 16 format 999
col 17 format 999
col 18 format 999
col 19 format 999
col 20 format 999
col 21 format 999
col 22 format 999
col 23 format 999
select thread# as INST, trunc(completion_time) as "date", 
to_char(completion_time,'Dy') as "Day",
sum(decode(to_char(completion_time,'HH24'),'00',1,0)) as "00",
sum(decode(to_char(completion_time,'HH24'),'01',1,0)) as "01",
sum(decode(to_char(completion_time,'HH24'),'02',1,0)) as "02",
sum(decode(to_char(completion_time,'HH24'),'03',1,0)) as "03",
sum(decode(to_char(completion_time,'HH24'),'04',1,0)) as "04",
sum(decode(to_char(completion_time,'HH24'),'05',1,0)) as "05",
sum(decode(to_char(completion_time,'HH24'),'06',1,0)) as "06",
sum(decode(to_char(completion_time,'HH24'),'07',1,0)) as "07",
sum(decode(to_char(completion_time,'HH24'),'08',1,0)) as "08",
sum(decode(to_char(completion_time,'HH24'),'09',1,0)) as "09",
sum(decode(to_char(completion_time,'HH24'),'10',1,0)) as "10",
sum(decode(to_char(completion_time,'HH24'),'11',1,0)) as "11",
sum(decode(to_char(completion_time,'HH24'),'12',1,0)) as "12",
sum(decode(to_char(completion_time,'HH24'),'13',1,0)) as "13",
sum(decode(to_char(completion_time,'HH24'),'14',1,0)) as "14",
sum(decode(to_char(completion_time,'HH24'),'15',1,0)) as "15",
sum(decode(to_char(completion_time,'HH24'),'16',1,0)) as "16",
sum(decode(to_char(completion_time,'HH24'),'17',1,0)) as "17",
sum(decode(to_char(completion_time,'HH24'),'18',1,0)) as "18",
sum(decode(to_char(completion_time,'HH24'),'19',1,0)) as "19",
sum(decode(to_char(completion_time,'HH24'),'20',1,0)) as "20",
sum(decode(to_char(completion_time,'HH24'),'21',1,0)) as "21",
sum(decode(to_char(completion_time,'HH24'),'22',1,0)) as "22",
sum(decode(to_char(completion_time,'HH24'),'23',1,0)) as "23",
 count(1) as "total"
from
v\$archived_log
where first_time > trunc(sysdate-7)
and dest_id = (select dest_id from V\$ARCHIVE_DEST_STATUS where status='VALID' and type='LOCAL')
group by thread#, trunc(completion_time), to_char(completion_time, 'Dy') order by 2 desc ,1;

PROMPT
PROMPT Standby  Sync 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col HOSTNAME for a24
SELECT  DISTINCT GVD.INST_ID,
(SELECT UPPER(SUBSTR(HOST_NAME,1,(DECODE(INSTR(HOST_NAME,'.'),0,LENGTH(HOST_NAME), (INSTR(HOST_NAME,'.')-1))))) FROM GV\$INSTANCE WHERE INST_ID=GVI.INST_ID) HOSTNAME,
GVD.NAME "DATABASE",
(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE ARCHIVED='YES' AND DEST_ID=2 AND THREAD# = GVI.THREAD#) LOG_ARCHIVED,
(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES' AND THREAD# = GVI.THREAD#) LOG_APPLIED,
(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE ARCHIVED='YES' AND DEST_ID=2 AND THREAD# = GVI.THREAD#)-(SELECT MAX(SEQUENCE#) FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES' AND THREAD# = GVI.THREAD#) LOG_GAP,
(SELECT TO_CHAR(MAX(COMPLETION_TIME),'DD-MON/HH24:MI') FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES') APPLIED_TIME
FROM GV\$DATABASE GVD, GV\$INSTANCE GVI, V\$ARCHIVED_LOG GVA
WHERE GVI.THREAD#=GVA.THREAD#
AND GVI.INST_ID=GVD.INST_ID
ORDER BY GVD.INST_ID;

PROMPT
PROMPT ALERT LOG 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col originating_timestamp for a25
col rownum for 999999
col Error for a150
ALTER SESSION SET NLS_LANGUAGE = 'AMERICAN';
select inst_id, -- rownum "Line",
TO_CHAR(originating_timestamp,'DD-MON-YYYY HH24:MI:SS') AS time, message_text "Error"
from TABLE(gv\$(cursor(select inst_id, originating_timestamp, message_text
from v\$diag_alert_ext
where originating_timestamp >= (sysdate - 1) AND message_type not IN (1) 
AND regexp_like(message_text, '(ORA-|error)'))))
order by originating_timestamp asc;

PROMPT
PROMPT MODIFIED PARAMETERS SINCE INSTANCE STARTUP:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col INS for 999
col name for a45
col VALUE for a80
col DEPRECATED for a10
select INST_ID INS,NAME,VALUE,ISDEFAULT "DEFAULT",ISDEPRECATED "DEPRECATED" from gv\$parameter where ISMODIFIED = 'SYSTEM_MOD' order by 1;

PROMPT
PROMPT RESOURCE LIMIT:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col INITIAL_ALLOCATION  for a20
col LIMIT_VALUE         for a20
col RESOURCE_NAME       for a40
select * from gv\$resource_limit order by RESOURCE_NAME,1;

spool off
exit;
EOF_CDB

### Loop for each PDB details 
for pdb in $pdbs; 
do
   sqlplus -S "/ as sysdba" <<EOF_PDB
   CLEAR BREAKS
   CLEAR COLUMNS
   set colsep |
   set lines 200 pages 200
   SET HEAD ON
   SET FEEDBACK OFF
   spool /tmp/DBHC_${ORACLE_UNQNAME}_${timestamp}.txt append
   alter session set container=$pdb;

PROMPT
PROMPT
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PROMPT CONNECTED TO PDB - $pdb 

PROMPT
PROMPT PDB Registry
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col STATUS for a15
col COMP_NAME for a40
col comp_id for a12
select COMP_ID,COMP_NAME,VERSION,STATUS,MODIFIED from dba_registry;

PROMPT
PROMPT ACTIVE-INACTIVE SESSIONS 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col username for a28
col status for a15
comp sum of session_count on report
bre on report
SELECT s.username,COUNT(*) AS session_count, s.status
FROM gV\$SESSION S,gV\$PROCESS P
WHERE S.PADDR=P.ADDR
AND S.USERNAME IS NOT NULL
group by s.username,s.status
ORDER BY 3,2 desc;

PROMPT
PROMPT ACTIVE SESSIONS - BY Wait Events
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col event for a50
select inst_id,event,count(*) from gv\$session where username is not null and status='ACTIVE'
and event not in('SQL*Net message from client','SQL*Net message to client','smon timer','pmon timer','Streams AQ: waiting for messages in the queue')
group by inst_id,event order by 1,3;

PROMPT
PROMPT ACTIVE SESSIONS
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

col inst_id for 99
col username for a22 Head "DB User"
col osuser for a14
col event for a20 trunc
col inst for 99999
col SESS for a15
col module for a35
select inst_id, s.sid||','||s.serial# as SESS , s.username,osuser, s.sql_id,s.sql_child_number Parallel,
rpad(upper(substr(s.MODULE,instr(s.MODULE,'\',-1)+1)),29,' ') as "MODULE", s.event,
round(LAST_CALL_ET/60) ACTIVE_Mins
from gv\$session s
where s.status='ACTIVE' and username is not null
and s.username not like 'SYS%' and s.username not like 'DBSNMP'
and s.event not in('SQL*Net message from client','SQL*Net message to client','smon timer','pmon timer','Streams AQ: waiting for messages in the queue')
and rownum <=25
order by LAST_CALL_ET desc ;

PROMPT
PROMPT Queries Running For More Than [${LONG_RUN_QUR_HOURS}] Hour:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col module for a30
col DURATION_HOURS for 99999.9 
col STARTED_AT for a13
col "USERNAME| SID,SERIAL#" for a26
col "SQL_ID | SQL_TEXT" for a95
SELECT
    username || '| ' || sid || ',' || serial# AS "USERNAME| SID,SERIAL#",
    SUBSTR(MODULE, 1, 30) AS "MODULE",
    TO_CHAR(SYSDATE - last_call_et / 24 / 60 / 60, 'DD-MON HH24:MI') AS STARTED_AT,
    last_call_et / 60 / 60 AS "DURATION_HOURS",
    SQL_ID || ' | ' ||
    SUBSTR((SELECT LISTAGG(SUBSTR(SQL_FULLTEXT, 1, 77), '; ') WITHIN GROUP (ORDER BY SQL_FULLTEXT) FROM gv\$sql WHERE address = sql_address), 1, 77) AS "SQL_ID | SQL_TEXT"
FROM  gv\$session
WHERE
    username IS NOT NULL
    AND module IS NOT NULL
    AND last_call_et > 60 * 60 * ${LONG_RUN_QUR_HOURS}
    AND status = 'ACTIVE';

PROMPT
PROMPT BLOCKED SESSIONS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col module for a27
col event for a24
col MACHINE for a27
col "WA_ST|WAITD|ACT_SINC|LOG_T" for a38
col "INS|USER|SID,SER|MACHIN|MODUL" for a70
col "PREV|CURR SQLID" for a27
col "I|BLKD_BY" for a12
select /*+RULE*/
substr(s.INST_ID||'|'||s.USERNAME||'| '||s.sid||','||s.serial#||' |'||substr(s.MACHINE,1,22)||'|'||substr(s.MODULE,1,18),1,65)"INS|USER|SID,SER|MACHIN|MODUL"
,substr(w.state||'|'||round(w.WAIT_TIME_MICRO/1000000)||'|'||LAST_CALL_ET||'|'||to_char(LOGON_TIME,'ddMon'),1,38) "WA_ST|WAITD|ACT_SINC|LOG_T"
,substr(w.event,1,24) "EVENT"
,s.FINAL_BLOCKING_INSTANCE||'|'||s.FINAL_BLOCKING_SESSION "I|BLKD_BY"
from    gv\$session s, gv\$session_wait w
where   s.USERNAME is not null
and     s.FINAL_BLOCKING_SESSION is not null
and     s.sid=w.sid
and     s.STATUS='ACTIVE'
order by "I|BLKD_BY" desc,w.event,"INS|USER|SID,SER|MACHIN|MODUL","WA_ST|WAITD|ACT_SINC|LOG_T" desc;

PROMPT
PROMPT TABELSPACE SIZE:  
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col tablespace_name for A25
col Total_MB for 999999999999
col Used_MB for 999999999999
col '%Used' for 999.99
comp sum of Total_MB on report
comp sum of Used_MB   on report
bre on report
select tablespace_name,
       (tablespace_size*$blksize)/(1024*1024) Total_MB,
       (used_space*$blksize)/(1024*1024) Used_MB,
       to_char(used_percent,999.99) "%Used"
from dba_tablespace_usage_metrics ORDER BY 4 DESC;

PROMPT
PROMPT CURRENT RUNNING JOBS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col INS                         for 999
col "JOB_NAME|OWNER|SPID|SID"   for a55
col ELAPSED_TIME                for a17
col CPU_USED                    for a17
col "WAIT_SEC"                  for 9999999999
col WAIT_CLASS                  for a15
col "BLKD_BY"                   for 9999999
col "WAITED|WCLASS|EVENT"       for a45
select j.RUNNING_INSTANCE INS,j.JOB_NAME ||' | '|| j.OWNER||' |'||SLAVE_OS_PROCESS_ID||'|'||j.SESSION_ID"JOB_NAME|OWNER|SPID|SID"
,s.FINAL_BLOCKING_SESSION "BLKD_BY",ELAPSED_TIME,CPU_USED
,substr(s.SECONDS_IN_WAIT||'|'||s.WAIT_CLASS||'|'||s.EVENT,1,45) "WAITED|WCLASS|EVENT",S.SQL_ID
from dba_scheduler_running_jobs j, gv\$session s
where   j.RUNNING_INSTANCE=S.INST_ID(+)
and     j.SESSION_ID=S.SID(+)
order by "JOB_NAME|OWNER|SPID|SID",ELAPSED_TIME;

PROMPT
PROMPT FAILED DBMS_SCHEDULER JOBS IN THE LAST 24H:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col LOG_DATE for a36
col OWNER for a15
col JOB_NAME for a35
col STATUS for a11
col RUN_DURATION for a20
col ID for 99
select INSTANCE_ID ID,JOB_NAME,OWNER,LOG_DATE,STATUS,ERROR#,RUN_DURATION from DBA_SCHEDULER_JOB_RUN_DETAILS where LOG_DATE > sysdate-1 and STATUS='FAILED' order by JOB_NAME,LOG_DATE;

PROMPT 
PROMPT Active Incidents:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col RECENT_PROBLEMS_1_WEEK_BACK for a55
select SUBSTR(PROBLEM_KEY,1,40) RECENT_PROBLEMS_1_WEEK_BACK,to_char(FIRSTINC_TIME,'DD-MON-YY HH24:mi:ss') FIRST_OCCURENCE,to_char(LASTINC_TIME,'DD-MON-YY HH24:mi:ss')
LAST_OCCURENCE FROM V\$DIAG_PROBLEM WHERE LASTINC_TIME > SYSDATE -15;

PROMPT 
PROMPT OUTSTANDING ALERTS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col CREATION_TIME for a40
col REASON for a80
select REASON,CREATION_TIME,METRIC_VALUE from DBA_OUTSTANDING_ALERTS;

PROMPT 
PROMPT CORRUPTED BLOCKS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
select * from V\$DATABASE_BLOCK_CORRUPTION;


PROMPT
PROMPT AUTOTASK INTERNAL MAINTENANCE WINDOWS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col WINDOW_NAME for a17
col NEXT_RUN for a20
col ACTIVE for a6
col OPTIMIZER_STATS for a15
col SEGMENT_ADVISOR for a15
col SQL_TUNE_ADVISOR for a16
SELECT WINDOW_NAME,TO_CHAR(WINDOW_NEXT_TIME,'DD-MM-YYYY HH24:MI:SS') NEXT_RUN,AUTOTASK_STATUS STATUS,WINDOW_ACTIVE ACTIVE,OPTIMIZER_STATS,SEGMENT_ADVISOR,SQL_TUNE_ADVISOR FROM DBA_AUTOTASK_WINDOW_CLIENTS;

PROMPT 
PROMPT DATABASE MEMORY UTILIZATION:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col inst_id  for 999
col COMPONENT           for a30
col CURRENT_SIZE_MB     for 99999999999
col MAX_SIZE_MB         for 99999999999
select INST_ID,COMPONENT,USER_SPECIFIED_SIZE/1024/1024 USER_SPECIFIED_SIZE_MB,CURRENT_SIZE/1024/1024 CURRENT_SIZE_MB,MAX_SIZE/1024/1024 MAX_SIZE_MB from gv\$memory_dynamic_components where COMPONENT not like '%K buffer%' and COMPONENT not in ('ASM Buffer Cache','KEEP buffer cache','RECYCLE buffer cache','unified pga pool','Data Transfer Cache') order by COMPONENT,INST_ID;

PROMPT
PROMPT MEMORY ADVISORS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PROMPT 
PROMPT SGA ADVISOR:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

col ESTD_DB_TIME for 99999999999999999
col ESTD_DB_TIME_FACTOR for 99999999999999999999
select * from V\$SGA_TARGET_ADVICE where SGA_SIZE_FACTOR > .6 and SGA_SIZE_FACTOR < 1.6;

PROMPT  
PROMPT BUFFER CACHE ADVISOR:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col ESTD_SIZE_MB for 9999999999999
col ESTD_PHYSICAL_READS for 99999999999999999999
col ESTD_PHYSICAL_READ_TIME for 99999999999999999999
select SIZE_FACTOR "%SIZE",SIZE_FOR_ESTIMATE ESTD_SIZE_MB,ESTD_PHYSICAL_READS,ESTD_PHYSICAL_READ_TIME,ESTD_PCT_OF_DB_TIME_FOR_READS
from V\$DB_CACHE_ADVICE where SIZE_FACTOR >.8 and SIZE_FACTOR<1.3;

PROMPT 
PROMPT SHARED POOL ADVISOR:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col SIZE_MB for 99999999999
col SIZE_FACTOR for 99999999
col ESTD_SIZE_MB for 999999999999
col LIB_CACHE_SAVED_TIME for 9999999999999999999
select SHARED_POOL_SIZE_FOR_ESTIMATE SIZE_MB,SHARED_POOL_SIZE_FACTOR "%SIZE",SHARED_POOL_SIZE_FOR_ESTIMATE/1024/1024 ESTD_SIZE_MB,ESTD_LC_TIME_SAVED LIB_CACHE_SAVED_TIME,
ESTD_LC_LOAD_TIME PARSING_TIME from V\$SHARED_POOL_ADVICE
where SHARED_POOL_SIZE_FACTOR > .9 and SHARED_POOL_SIZE_FACTOR  < 1.6;

PROMPT 
PROMPT PGA ADVISOR:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col SIZE_FACTOR  for 999999999
col ESTD_SIZE_MB for 99999999999999999999
col MB_PROCESSED for 99999999999999999999
col ESTD_TIME for 99999999999999999999
select PGA_TARGET_FACTOR "%SIZE",PGA_TARGET_FOR_ESTIMATE/1024/1024 ESTD_SIZE_MB,BYTES_PROCESSED/1024/1024 MB_PROCESSED,
ESTD_TIME,ESTD_PGA_CACHE_HIT_PERCENTAGE PGA_HIT,ESTD_OVERALLOC_COUNT PGA_SHORTAGE
from V\$PGA_TARGET_ADVICE where PGA_TARGET_FACTOR > .7 and PGA_TARGET_FACTOR < 1.6;


PROMPT 
PROMPT TOP FRAGMENTED TABLES:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col "%RECLAIMABLE_SPACE" for 99
col owner                for a30
col "%FRAGMENTED_SPACE"  for a17
col LAST_ANALYZED for a13
col TABLE_NAME for a32
col owner for a28
select * from (select owner,table_name,to_char(LAST_ANALYZED, 'DD-MON-YYYY') LAST_ANALYZED,
round(blocks * ${blksize}/1024/1024)     "FULL_SIZE_MB",
round(num_rows * avg_row_len/1024/1024)  "ACTUAL_SIZE_MB",
round(blocks * ${blksize}/1024/1024) - round(num_rows * avg_row_len/1024/1024) "FRAGMENTED_SPACE_MB",
round(((round((blocks * ${blksize}/1024/1024)) - round((num_rows * avg_row_len/1024/1024))) / round((blocks * ${blksize}/1024/1024))) * 100)||'%' "%FRAGMENTED_SPACE"
from dba_tables
where blocks>10
-- Exclude SYS objects:
and owner <> 'SYS'
and round(blocks * ${blksize}/1024/1024) > 10
-- Fragmented Space must be > 30%:
and ((round((blocks * ${blksize}/1024/1024)) - round((num_rows * avg_row_len/1024/1024))) / round((blocks * ${blksize}/1024/1024))) * 100 > 30
order by "FRAGMENTED_SPACE_MB" desc) where rownum<11;

PROMPT
PROMPT Hint: The accuracy of the FRAGMENTED TABLES list depends on having a recent STATISTICS.

PROMPT
PROMPT RECYCLEBIN OBJECTS#: [Purging DBA_RECYCLEBIN can boost the performance of X$ tables]
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col "RECYCLED_OBJECTS#" for 999999999999999999
col "TOTAL_SIZE_MB"     for 99999999999999
set feedback off
select
 count(*) "RECYCLED_OBJECTS#",
 sum(space)*${blksize}/1024/1024 "TOTAL_SIZE_MB"
from dba_recyclebin group by 1;

PROMPT
PROMPT CURRENT OS / HARDWARE STATISTICS:
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col STAT_NAME for a30
col value for 99999999999999
select stat_name,value from v\$osstat;

PROMPT
prompt No of Created objects [Last 24H]
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col owner for a30
col object_name for a30
col object_type for a19
col created for a20
select count(*),object_type,owner from dba_objects
where created > sysdate-1
and owner <> 'SYS'
group by object_type,owner
order by owner,object_type;

prompt
prompt Modified objects in the Last 24H ...
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col owner for a30
col object_name for a30
col object_type for a19
col LAST_DDL_TIME for a20
select count(*),object_type,owner from dba_objects
where LAST_DDL_TIME > sysdate-1
and owner <> 'SYS'
group by object_type,owner
order by owner,object_type;

spool off
exit;
EOF_PDB
done 

echo -e "\t*** DB HC Report successfully created  at ${cur_dir}/Reports/HC_RPT/DBHC_${ORACLE_UNQNAME}_${timestamp}.txt "
echo -e "\n"
echo -e "\n\t*** Press q to return: \c."
read option
        if [ "$option" = "q" -o "$option" = "Q" ]
        then
            tput clear
          exit 0
        fi

